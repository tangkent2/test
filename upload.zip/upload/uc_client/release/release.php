<?php

if(!defined('UC_CLIENT_VERSION')) {
	define('UC_CLIENT_VERSION', '1.7.0');
	define('UC_CLIENT_RELEASE', '20230316');
}