<?php

if(!defined('UC_SERVER_VERSION')) {
	define('UC_SERVER_VERSION', '1.7.0');
	define('UC_SERVER_RELEASE', '20230316');
}