<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id$
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$lang = array
(
	'attackevasive_1_subject' => '频繁刷新限制',
	'attackevasive_1_message' => '您访问本站速度过快或者刷新间隔时间小于两秒！请等待页面自动跳转 ...',
	'attackevasive_2_subject' => '代理服务器访问限制',
	'attackevasive_2_message' => '本站现在限制使用代理服务器访问，请去除您的代理设置，直接访问本站。',
	'attackevasive_4_subject' => '页面重载开启',
	'attackevasive_4_message' => '欢迎光临本站，页面正在重新载入，请稍候 ...',
);